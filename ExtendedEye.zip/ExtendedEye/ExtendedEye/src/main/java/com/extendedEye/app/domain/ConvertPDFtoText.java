package com.extendedEye.app.domain;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;

public class ConvertPDFtoText {
	public static PrintWriter pw = null;
	public static PdfReader reader = null;
    public static boolean extractTextFromPDF(File pFile, File pOutput, boolean pOverwrite) {

		if (pOutput.exists() & (!pOverwrite)) {
			return false;
		}

		boolean ret = true;
		try {
			pw = new PrintWriter(new FileWriter(pOutput));
			reader = new PdfReader(pFile.getAbsolutePath());
			PdfReaderContentParser parser = new PdfReaderContentParser(reader);
			TextExtractionStrategy strategy;
			for (int i = 0; i < reader.getNumberOfPages(); i++) {
				try {
					strategy = parser.processContent((i + 1), new SimpleTextExtractionStrategy());
					pw.println(strategy.getResultantText());
					System.out.println(strategy.getResultantText());
				} catch (ExceptionConverter e) {
					e.printStackTrace();
					ret = false;
					pw.println("iText Exception: Page " + (i + 1) + ": " + e.getClass().getName() + ": " + e.getMessage());
				}
			}
		} catch (IOException e) {
			ret = false;
			e.printStackTrace();
		} finally {
			if (pw != null)
				pw.close();
			if (reader != null)
				reader.close();
		}

		return ret;
	}
}
