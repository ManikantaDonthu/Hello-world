package com.extendedEye.app.controller;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.extendedEye.app.domain.ConvertPDFtoText;
import com.extendedEye.app.domain.NLPExample;

@Controller
public class IndexController {
	private static final File FILE_NAME = new File(System.getProperty("user.home")+"\\Downloads\\Ship Details.pdf");
	private static final File FILE_OUTPUT_NAME = new File(System.getProperty("user.home")+"\\Downloads\\Ship Details.txt");
	public static final String URL = "https://www.vesseltracker.com/";
	
	@RequestMapping("/")
	public String home(Map<String, Object> model) throws IOException, URISyntaxException, InterruptedException {
		boolean dataExist = ConvertPDFtoText.extractTextFromPDF(FILE_NAME, FILE_OUTPUT_NAME, true);
		if (dataExist) {
			List allSearchWords = NLPExample.partsOfWords();
			if (allSearchWords.size()> 0) {
				//return "redirect:" +URL;
				  //259924000
			}
			model.put("message", "HowToDoInJava Reader !!");
			return "index";	
		}
		else{
			return "dataNotExist";
		}
		
	}
	
	@RequestMapping("/next")
	public String next(Map<String, Object> model) {
		model.put("message", "You are in new page !!");
		return "next";
	}

}