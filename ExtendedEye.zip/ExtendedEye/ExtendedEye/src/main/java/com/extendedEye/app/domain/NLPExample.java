package com.extendedEye.app.domain;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSSample;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

public class NLPExample {
	//public static void main(String args[]){ 
	public static List partsOfWords() {	
		String nameSentence = " What:  Type: General Cargo/ Container IMO No.: 000000 Callsign: XRSIZE MMSI: 987654321 Crew: Typically totals 12 officers and ratings  Deadweight: 42,123 DWT on 12M"
				+ "	 Draft Dimensions: Lbp x B x D: 127.00 - 212. x 32.28 x 19.30 M GRT - NRT: 36836 - 17696 T Container Capacity: 3078 TEU, Including 615 Reefer Plugs Holds - Hatches: 2 - 2 GearR: Cranes, 35T SWL x 2 Main Engine: MAN-B&W 3K80ME-C, 2880 KW RPM: 104 ";
		
		POSModel posModel = null;
		TokenizerModel tokenModel = null;
		
		try {
			//Loading the Tokenizer model 
			InputStream inputStreamForToken = new FileInputStream("C:\\DO NOT DELETE\\ApacheNLP\\en-token.bin");
			tokenModel = new TokenizerModel(inputStreamForToken);
			
			//Loading Parts of speech-maxent model : Parts of speech
			InputStream inputStreamForPOS = new FileInputStream("C:\\DO NOT DELETE\\ApacheNLP\\en-pos-maxent.bin"); 
			posModel = new POSModel(inputStreamForPOS);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
	    
	    //Instantiating the TokenizerME class 
	    TokenizerME tokenizer = new TokenizerME(tokenModel);
		
		//Instantiating POSTaggerME class 
		POSTaggerME tagger = new POSTaggerME(posModel);
		
		String rawTokens3[] = tokenizer.tokenize(nameSentence);
		
		//Generating tags 
		String[] tags = tagger.tag(rawTokens3); 
		
		ArrayList<String> allSearchingWords = new ArrayList<>();
		 for(int i=0;i<rawTokens3.length;i++){
			 System.out.println(rawTokens3[i]+"\t:\t"+tags[i]);
              if (tags[i].equals("NNP") || tags[i].equals("NNS") || tags[i].equals("CD")) {
            	  allSearchingWords.add(rawTokens3[i]);
              }
         }
	//}
		return allSearchingWords;
	}
}
