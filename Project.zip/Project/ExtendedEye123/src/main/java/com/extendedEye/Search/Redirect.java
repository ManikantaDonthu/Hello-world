package com.extendedEye.Search;

import java.awt.Desktop;
import java.net.URI;

public class Redirect {
	public static final String URL = "https://www.vesseltracker.com/";
	public static void main(String args[]) {
		callURL(URL);
	}
	public static void callURL(String myURL) {
		try {
			if(Desktop.isDesktopSupported())
			{
			  Desktop.getDesktop().browse(new URI(myURL));
			  Thread.sleep(5000);
			  ScriptExecuteEngine.executeScript();
			  //259924000
			}
		} catch (Exception e) {
			throw new RuntimeException("Exception while calling URL:" + myURL, e);
		}
	}
}
