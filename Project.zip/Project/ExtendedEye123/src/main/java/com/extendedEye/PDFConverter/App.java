package com.extendedEye.PDFConverter;

import java.io.File;

/**
 * Hello world!
 *
 */
public class App 
{
	
	private static final File FILE_NAME = new File(System.getProperty("user.home")+"\\Downloads\\ShipDetails.pdf");
	private static final File FILE_OUTPUT_NAME = new File(System.getProperty("user.home")+"\\Downloads\\ShipDetails.txt");

	public static void main( String[] args )
    {
		System.out.println(FILE_NAME);
    	ConvertPDFtoText.extractTextFromPDF(FILE_NAME, FILE_OUTPUT_NAME, true);
    }
}
