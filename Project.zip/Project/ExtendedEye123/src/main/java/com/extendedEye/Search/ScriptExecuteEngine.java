package com.extendedEye.Search;


public class ScriptExecuteEngine {
	public static void main (String args[]) throws Exception {
		executeScript();
	}
	public static void executeScript() throws Exception{
		  
        try {
        	
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
}

}